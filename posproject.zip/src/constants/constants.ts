export const constants = {
    loaderTemplate: `<div class="loader loader-2">
    <span></span>
    <span></span>
    <span></span>
  </div>`,
  };