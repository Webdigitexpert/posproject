import { RangePipe } from './range.pipe';

describe('RangePipe', () => {
  it('create an instance', () => {
    const pipe = new RangePipe();
    expect(pipe).toBeTruthy();
  });
});
