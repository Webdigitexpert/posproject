export const environment = {
  production: true,
  noAuthentication: false,
  currencyFormat: {
    symbol: 'INR',
    name: 'dollar'
  },
  basePath: 'http://162.241.201.237:7000/api/',
  imageUrl: 'http://162.241.201.237:7000/',
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYwZmI5M2ViMDNiMjc4NTY0MjIxODA2MyIsImlhdCI6MTYyNzI3MTkyMCwiZXhwIjoxNjI3MzU4MzIwfQ.eJuLplS51V4iPGF--VlvlYaftJg8NJYKWh8ZkjGBqEk",

};
