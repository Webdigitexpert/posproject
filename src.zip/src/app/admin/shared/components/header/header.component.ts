import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
//import { MatDialog } from "@angular/material/dialog";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  public loginuser: any = window.localStorage.getItem('loggedUser');
  constructor(public router: Router, public authService:AuthService) {}
  public data = {
    type: 'text',
  };
  openDialog() {}

  ngOnInit(): void {
    if (window.localStorage.getItem('loggedUser') == null) {
      this.loginuser = '';
    }
  }
  logout() {
    this.authService.logout()
    this.router.navigate(['/admin'])
  }
}
