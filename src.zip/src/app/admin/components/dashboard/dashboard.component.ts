import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { EmployeeService } from 'src/app/shared/services/employee/employee.service';
import { OrdersService } from 'src/app/shared/services/orders/orders.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  constructor(private orderService: OrdersService,private employeeService:EmployeeService) {}
  public columns = [
    {
      label: 'Employee Name',
      field: 'employee_id',
      isText: true,
    },
    {
      label: 'Order Date',
      field: 'order_date_and_time',
      isText: true,
    },
    {
      label: 'Order Amount',
      field: 'order_amount',
      isPrice: true,
    },
  ];
  public selectEmployee:any;

  public dashboardData: any;
  data: SimpleDataModel[] = [
    {
      name: 'text1',
      value: '95',
    },
    {
      name: 'text1',
      value: '4',
    },
    {
      name: 'text3',
      value: '1',
    },
  ];
  public loaderShow: boolean = false;
  public fullScreen: boolean = true;
  public loaderTemplate = environment.loaderTemplate;
  public fromdateSearch:any;
  public todateSearch:any;
  public searchForm:FormGroup;

  ngOnInit(): void {
    this.loaderShow = true;
    this.searchForm = new FormGroup({
      employee_id : new FormControl('',[])
    })
    this.orderService.getOrders().subscribe(
      (res) => {
        this.loaderShow = false;
        this.dashboardData = res;
        console.log(res);
      },
      (err) => {
        console.log(err);
      }
    );

    this.employeeService.getEmployee().subscribe((res)=>{
      console.log(res);
      this.selectEmployee = res;
    },(err)=>{console.log(err)})

  
  }

  getOrders(data){
    this.loaderShow = true;
    this.fromdateSearch = data.fromDate;
    this.todateSearch = data.toDate;
    this.orderService.searchOrderByDates(this.fromdateSearch,this.todateSearch).subscribe((res)=>{console.log(res)
    this.dashboardData = res;
    this.loaderShow = false;
    },(err)=>{console.log(err)})
  }

  employeeSelect(event:any){
    this.loaderShow = true;
    console.log(this.searchForm.value)
    this.orderService.searchOrderByDatesandEmployee(this.searchForm.value.employee_id,this.fromdateSearch,this.todateSearch).subscribe((res)=>{console.log(res)
      this.loaderShow = false;
      this.dashboardData = res;
    },
    (err)=>{console.log(err)})
    console.log(event.target.value)
  }

}
export interface SimpleDataModel {
  name: string;
  value: string;
  color?: string;
}
